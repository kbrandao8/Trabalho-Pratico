var searchData=
[
  ['card_0',['card',['../classcard.html#ace923c0be659979478cf40965d728f3f',1,'card']]]
];
