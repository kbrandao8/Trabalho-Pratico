var searchData=
[
  ['play_5fcard_0',['play_card',['../classbot.html#a0b0d17d5a21edd76cef9c438f2467f68',1,'bot']]],
  ['player_1',['player',['../classplayer.html',1,'']]],
  ['pontos_2',['pontos',['../classplayer.html#a2c4b523e660f114ebcd21a99f0984282',1,'player']]]
];
