var searchData=
[
  ['get_5fjogadores_0',['get_jogadores',['../classmenu.html#a7c4b27416cc1a8aa901e855e67569ff7',1,'menu']]],
  ['get_5fsuit_1',['get_suit',['../classcard.html#a86a6435ba10f186a1b47e7f73f8ba18b',1,'card']]],
  ['give_5fup_2',['give_up',['../classbot.html#ab581085925f0c236ee8a791935712643',1,'bot']]]
];
