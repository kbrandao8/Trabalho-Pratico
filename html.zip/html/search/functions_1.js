var searchData=
[
  ['bot_0',['bot',['../classbot.html#ad684a029a327d44c5d9bb9147c47baf1',1,'bot']]]
];
