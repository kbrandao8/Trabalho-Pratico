var searchData=
[
  ['accept_5frefuse_5ftruco_0',['accept_refuse_truco',['../classbot.html#a6d8732b8c7cd9efb6ecb14335606eed4',1,'bot']]],
  ['ask_5ftruco_1',['ask_truco',['../classbot.html#ae977bdd0655b505cc9dc1fcf594618a7',1,'bot']]]
];
