var indexSectionsWithContent =
{
  0: "abcdghmprt",
  1: "bcdhmpr",
  2: "abcdgmp",
  3: "p",
  4: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Funções",
  3: "Variáveis",
  4: "Páginas"
};

