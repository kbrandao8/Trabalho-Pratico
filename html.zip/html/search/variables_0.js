var searchData=
[
  ['pontos_0',['pontos',['../classplayer.html#a2c4b523e660f114ebcd21a99f0984282',1,'player']]]
];
