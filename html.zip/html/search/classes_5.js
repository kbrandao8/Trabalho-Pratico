var searchData=
[
  ['player_0',['player',['../classplayer.html',1,'']]]
];
